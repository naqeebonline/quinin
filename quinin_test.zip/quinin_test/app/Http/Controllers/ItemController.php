<?php

namespace App\Http\Controllers;

use App\Models\Item;
use function foo\func;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class ItemController extends Controller
{
    public function index()
    {
        return view('home');
    }//.... end of index()  .....//

    public function listItems()
    {
        $search = $_GET["query"] ?? "";
        $items = Item::orderBy("id","DESC")->where(["user_id"=>Auth::user()->id])->when($search,function ($query,$search){
            return $query->where('name', 'like', '%' . $search . '%');
        })->paginate(5);
        foreach ($items as $key=> $value){
            $res = "";
            foreach (json_decode($value->tags) as $key2 => $tag)
                $res .= $tag.", ";

            $value->tag_list = trim($res,", ");
        }
        return view('items.list-items',["items"=>$items]);
    }//.... end of index()  .....//

    //...... update and create item  ......//
    public function saveItem()
    {
        $validator = Validator::make(request()->all(), [
            'name'          => 'required',
            'descriptions'  => 'required',
            'tags'          => 'required',
        ]);

        if ($validator->fails())
            return ['status' => false, 'message' => 'Please provide all the required fields.'];

        $data = request()->except("id","tags");
        $data["tags"] = json_encode(request()->tags);
        $data["user_id"] = json_encode(Auth::user()->id);

        Item::updateOrCreate(["id" => request()->id], $data);
        Session::flash('message', 'item Saved successfully');
        return ["status" => true,"message"=>"item Saved successfully"];
    }//..... end of function saveItem()  .....//

    //..... delete item  .....//
    public function deleteItem($id)
    {
        Item::whereId($id)->delete();
        Session::flash('message', 'item deleted successfully');
        return ["status" => true,"message"=>"item deleted successfully"];
    }//.....  end of deleteItem()  .....//
}
