@extends('layouts.app')
@section('title', 'Add Item')
@section('content')
    <?php $tag = $item->tags ?? ""; ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <form method="post" action="{{route('save.item')}}">
                    {{csrf_field()}}
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Item Name</label>
                        <input type="hidden" name="id" class="form-control" value="<?php echo $id ?? 0; ?>">
                        <input type="text" name="name" value="{{$item->name ?? ""}}" class="form-control" id="name" placeholder="Item Name...">
                    </div>

                    <div class="form-group">
                        <label for="exampleFormControlTextarea1">Item Description</label>
                        <textarea class="form-control"  name="descriptions" id="descriptions" rows="3">{{$item->descriptions ?? ""}}</textarea>
                    </div>

                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Item Tags</label>
                        <select class="form-control" id="tags" name="tags" >
                            <option value="">Select Tag</option>
                            <option value="Red" {{($tag == "Red") ? 'selected' : ''}} >Red</option>
                            <option value="Green" {{($tag == "Green") ? 'selected' : ''}}>Green</option>
                            <option value="Blue" {{($tag == "Blue") ? 'selected' : ''}} >Blue</option>
                            <option value="Orange" {{($tag == "Orange") ? 'selected' : ''}} >Orange</option>
                        </select>
                    </div>


                </form>
            </div>
        </div>
    </div>


@endsection
