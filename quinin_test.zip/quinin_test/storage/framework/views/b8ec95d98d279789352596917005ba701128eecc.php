<?php /* F:\xampp\htdocs\quinin_test\resources\views/home.blade.php */ ?>
<?php $__env->startSection('title', 'List Items'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if(Session::has('message')): ?>
                <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    Dashboard
                </div>

               <div class="row">
                   <div class="col-md-4"></div>
                   <div class="col-md-4"><h5>Welcome to Todo List</h5></div>
                   <div class="col-md-4"></div>
               </div>


            </div>
        </div>
    </div>


    <div class="modal fade" id="item-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">New message</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="item_form" method="post">
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Item Name</label>
                            <input type="hidden" name="id" id="item_id" class="form-control" value="0">
                            <input type="text" name="name" value="" class="form-control" id="name" placeholder="Item Name...">
                        </div>

                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Item Description</label>
                            <textarea class="form-control"  name="descriptions" id="descriptions" rows="3"></textarea>
                        </div>


                        <div class="form-group">
                            <label for="exampleFormControlSelect1">Item Tags</label>
                            <select class="form-control selectpicker" name="tags[]" multiple data-live-search="true">
                                <option value="Red" >Red</option>
                                <option value="Green" >Green</option>
                                <option value="Blue"  >Blue</option>
                                <option value="Orange" >Orange</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"  id="close_popup" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" dusk="save-items" id="save_item">Save Item</button>
                </div>
            </div>
        </div>
    </div>



    <div class="modal fade" id="delete-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Item</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure to delete ?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="" data-dismiss="modal">No</button>
                    <button type="button" class="btn btn-primary" dusk="delete-items" id="delete_yes">Yes</button>
                </div>
            </div>
        </div>
    </div>



</div>

<script type="text/javascript">
    $(document).ready(function(){
        $('.selectpicker').selectpicker(["Red","Green"]);
        var delete_id = 0;
       $("body").on("click","#save_item",function(e){
           $("#item_form").ajaxSubmit({
               method:"POST",
               url:'<?php echo url("/save-item") ?>',
               success:function(res){
                   if(res.status){
                       $("#item-modal").modal("hide");
                       form_reset();
                       window.location.reload();
                   }else{
                       alert("Please Provide All Field Correctly");
                   }
               },
               error: function(err) {
                  console.log("Fill All Fields Correctly");
               }
           });
       });

       $("body").on("click",".edit_item",function () {
           form_reset();
         var value = JSON.parse($(this).attr('value'));
         $("#item_id").val(value.id);
         $("#name").val(value.name);
         $("#descriptions").val(value.descriptions);
         $("#tags").val(value.tags);
         $("#item-modal").modal("show");
         $('.selectpicker').val(JSON.parse(value.tags));
           $('.selectpicker').selectpicker('refresh')
       });

        $("body").on("click","#modal_main",function () {
            form_reset();
        });

        $("body").on("click",".delete_items",function () {
            $("#delete-modal").modal("show");
            delete_id = $(this).attr("id");
        });

        $("body").on("click","#delete_yes",function () {
            $.ajax({
                method:"GET",
                url:'<?php echo url("/delete-item") ?>/'+delete_id,
                success:function(res){
                    if(res.status){
                        $("#delete-modal").modal("hide");
                        form_reset();
                        window.location.reload();
                    }
                },
                error: function(err) {
                    alert("Error Occurred");
                }
            });
        });

        $("#search_item").on('keypress',function(e) {
            if(e.which == 13) {
                    if($(this).val() !=""){
                        window.location = '<?php echo route("home") ?>?query='+$(this).val();
                    }else{
                        window.location = '<?php echo route("home") ?>';
                    }

            }
        });
    });

    function form_reset() {
        $("#item_id").val(0);
        $("#name").val("");
        $("#descriptions").val("");
        $("#tags").val("");
        $('.selectpicker').val("");
        $('.selectpicker').selectpicker('refresh')
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>