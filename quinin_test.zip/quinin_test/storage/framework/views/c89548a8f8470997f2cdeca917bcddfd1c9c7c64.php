<?php /* F:\xampp\htdocs\laravel_eight\resources\views/items/add-item.blade.php */ ?>
<?php $__env->startSection('title', 'Add Item'); ?>
<?php $__env->startSection('content'); ?>
    <?php $tag = $item->tags ?? ""; ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <form method="post" action="<?php echo e(route('save.item')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="exampleFormControlInput1">Item Name</label>
                        <input type="hidden" name="id" class="form-control" value="<?php echo $id ?? 0; ?>">
                        <input type="text" name="name" value="<?php echo e($item->name ?? ""); ?>" class="form-control" id="name" placeholder="Item Name...">
                    </div>

                    <div class="form-group">
                        <label for="exampleFormControlTextarea1">Item Description</label>
                        <textarea class="form-control"  name="descriptions" id="descriptions" rows="3"><?php echo e($item->descriptions ?? ""); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Item Tags</label>
                        <select class="form-control" id="tags" name="tags" >
                            <option value="">Select Tag</option>
                            <option value="Red" <?php echo e(($tag == "Red") ? 'selected' : ''); ?> >Red</option>
                            <option value="Green" <?php echo e(($tag == "Green") ? 'selected' : ''); ?>>Green</option>
                            <option value="Blue" <?php echo e(($tag == "Blue") ? 'selected' : ''); ?> >Blue</option>
                            <option value="Orange" <?php echo e(($tag == "Orange") ? 'selected' : ''); ?> >Orange</option>
                        </select>
                    </div>


                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>