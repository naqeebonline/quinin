<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect("login");
});

Auth::routes(['verify' => true]);

Route::middleware('auth')->group(function() {
    Route::get('/home', 'ItemController@index')->name('home')->middleware('verified');
    Route::get('/list-items', 'ItemController@listItems');
    Route::get('/add-item', 'ItemController@addItem');
    Route::get('/update-item/{id}', 'ItemController@editItem');
    Route::post('/save-item', 'ItemController@saveItem');
    Route::delete('/delete-item/{id}', 'ItemController@deleteItem');
});


