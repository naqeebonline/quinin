<?php

namespace Tests\Browser;

use Illuminate\Foundation\Auth\User;
use Tests\DuskTestCase;
use Laravel\Dusk\Browser;
use Illuminate\Foundation\Testing\DatabaseMigrations;

class ExampleTest extends DuskTestCase
{
    /**
     * A basic browser test example.
     *
     * @return void
     */
    public function testBasicExample()
    {

        $itemName = "Coca Cola ".rand(111,999);
        $itemDesc = "Coca Cola ".rand(111,999);
        $url = url("/quinin_test/public");
        $this->browse(function (Browser $browser) use($itemDesc,$itemName,$url){
            $browser->visit($url)
                //...... login test  .....//
                    ->pause(2000)
                    ->type('email', "naqeebonline@gmail.com")
                    ->pause(1000)
                    ->type('password', "12345678")
                    ->pause(1000)
                    ->press('Login')
                    ->assertSee('Welcome to Todo List')
                    ->pause(3000)
                //..... end of login test  .....//

                //..... add items test   .....//

                    ->click('@list-items')
                    ->pause(2000)
                    ->click('@add-items')
                    ->pause(1000)
                    ->type('name', $itemName)
                    ->pause(1000)
                    ->type('descriptions', $itemDesc)
                    ->pause(2000)
                    ->select('tags[]', 'Red')
                    ->pause(2000)
                    ->select('tags[]', 'Green')
                    ->pause(2000)
                    ->click('@save-items')
                    ->pause(3000)
                    ->assertSee('item Saved successfully')
                //...... end of items test  .....//

                //..... search items    ......//
                    ->type("search_items",$itemName)
                    ->keys('.search_item', '{enter}')
                    ->pause(3000)
                //..... end of search items  ......//

                //...... update items test   .....//
                    ->with('.item_table', function ($table) use($itemName) {
                        $table->assertSee($itemName)
                            ->clickLink('Edit');
                     })
                    ->pause(1000)
                    ->type('name', $itemName)
                    ->pause(1000)
                    ->type('descriptions', $itemDesc." updated....")
                    ->pause(2000)
                    ->select('tags[]', 'Blue')
                    ->pause(2000)
                    ->click('@save-items')
                    ->pause(2000)
                    ->assertSee('item Saved successfully')
                //....... end of update item test    .....//

                //..... search items    ......//
                    ->type("search_items",$itemName)
                    ->keys('.search_item', '{enter}')
                    ->pause(3000)
                //..... end of search items  ......//

               //...... delete items test  ......//
                    ->with('.item_table', function ($table) use ($itemName) {
                        $table->assertSee($itemName)
                            ->clickLink('Delete');
                    })
                    ->pause(2000)
                    ->click('@delete-items')
                    ->pause(2000)
                //.....  end of delete items  .....//

                //..... logout user   ......//
                    ->click('@logout-drop-down')
                    ->pause(2000)
                    ->click('@click-logout')
                    ->pause(5000);

        });
    }
}
